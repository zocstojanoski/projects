//
//  UIImageView+Defaults.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/18/23.
//

import UIKit
import Alamofire
import AlamofireImage


extension UIImageView {
    
    func setImage(fromURL url: URL, animatedOnce: Bool = true, withPlaceholder placeholderImage: UIImage? = nil) {
        let hasImage: Bool = (self.image != nil)
        self.af.setImage(
            withURL: url,
            placeholderImage: placeholderImage,
            imageTransition: animatedOnce ? .crossDissolve(0.3) : .noTransition,
            runImageTransitionIfCached: hasImage
        )
    }
}
