//
//  ErrorResponse.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/18/23.
//

struct ErrorResponse: Codable, Error {
    var status_code: Int?
    var status_message: String?
    var success: Bool?
}
