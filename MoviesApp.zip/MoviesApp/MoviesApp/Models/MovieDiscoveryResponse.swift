//
//  MovieDiscoveryResponse.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/19/23.
//

struct MovieDiscoveryResponse: Codable {
    let page: Int
    let results: [MovieShow]
    let totalPages: Int
    let totalResults: Int
    
    enum CodingKeys: String, CodingKey {
        case page
        case results
        case totalPages = "total_pages"
        case totalResults = "total_results"
    }
}

struct MovieShow: Codable {
    let id: Int?
    let title: String?
    let name: String?
    let backdropPath: String?
    let voteAverage: Double?
    
    var budget: Int?
    var revenue: Int?
    
    let lastAirDate: String?
    let lastEpisodeToAir: Episode?
    
    enum CodingKeys: String, CodingKey {
        case id
        case title
        case name
        case backdropPath = "backdrop_path"
        case voteAverage = "vote_average"
        case budget
        case revenue
        case lastAirDate = "last_air_date"
        case lastEpisodeToAir = "last_episode_to_air"
    }
}

struct Episode: Codable {
    let name: String
}

struct GenreMovies {
    let genreID: Int
    var movies: [MovieShow]
}
