//
//  MovieGenresResponse.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/18/23.
//

struct MovieGenresResponse: Codable {
    let genres: [Genre]
}

struct Genre: Codable {
    let id: Int
    let name: String
}
