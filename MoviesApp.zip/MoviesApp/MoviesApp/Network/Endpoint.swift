//
//  Endpoint.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/18/23.
//

import Foundation

protocol Endpoint {
    var scheme: String { get }
    var host: String { get }
    var path: String { get }
    var method: RequestMethod { get }
    var header: [String: String]? { get }
    var body: Data? { get }
    var queryParameters: [URLQueryItem]? { get }
    var port: Int? { get }
}

extension Endpoint {
    var scheme: String {
        return "https"
    }
    
    var host: String {
        return "api.themoviedb.org/3"
    }
}

