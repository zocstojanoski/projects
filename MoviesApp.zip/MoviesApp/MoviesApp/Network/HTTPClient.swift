//
//  HTTPClient.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/18/23.
//

import Foundation

protocol HTTPClient {
    func sendRequest<T: Decodable>(endpoint: Endpoint, responseModel: T.Type) async -> Result<T, RequestError>
}

extension HTTPClient {
    func sendRequest<T: Decodable>(
        endpoint: Endpoint,
        responseModel: T.Type
    ) async -> Result<T, RequestError> {
        guard let request = createUrlRequest(for: endpoint) else {
            return .failure(.invalidURL)
        }
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request, delegate: nil)
            guard let response = response as? HTTPURLResponse else {
                return .failure(.noResponse)
            }
            
            switch response.statusCode {
            case 200...299:
                
                do {
                    let decodedResponse = try JSONDecoder().decode(responseModel, from: data)
                    return .success(decodedResponse)
                } catch(let err) {
                    print(",,,\(err)")
                }
                
                return .failure(.decode)
            case 400:
                do {
                    let clientError = try JSONDecoder().decode(ErrorResponse.self, from: data)
                    return .failure(RequestError.clientError(message: clientError.status_message))
                } catch(_) {
                    return .failure(RequestError.clientError(message: nil))
                }
            case 401:
                return .failure(.unauthorized)
            default:
                return .failure(.unexpectedStatusCode)
            }
        } catch {
            return .failure(.unknown)
        }
    }
    
    private func createUrlRequest(for endpoint: Endpoint) -> URLRequest? {
        let base = "\(endpoint.scheme)://\(endpoint.host)"
        let fullPath = "\(base)\(endpoint.path)"
        
        let queryString = endpoint.queryParameters?
            .map { "\($0.name)=\($0.value ?? "")" }
            .joined(separator: "&")
            .replacingOccurrences(of: "+", with: "%2B")
            .replacingOccurrences(of: ":", with: "%3A")
        
        let urlString = "\(fullPath)?\(queryString ?? "")"
        
        guard let url = URL(string: urlString) else {
            return nil
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = endpoint.method.rawValue
        request.allHTTPHeaderFields = endpoint.header
        
        if let body = endpoint.body {
            request.httpBody = body
        }
        
        return request
    }
    
}
