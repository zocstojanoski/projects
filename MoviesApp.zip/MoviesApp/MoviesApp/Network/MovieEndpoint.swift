//
//  MovieEndpoint.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/18/23.
//

import Foundation

enum MovieEndpoint {
    case movieGenres
    case showGenres
    case discoverMovies(genreID: Int, page: Int)
    case discoverTV(genreID: Int, page: Int)
    case movieDetails(movieID: Int)
    case showDetails(showID: Int)
}

extension MovieEndpoint: Endpoint {
    
    var commonParameters: [URLQueryItem] {
        return [
            URLQueryItem(name: "language", value: "en"),
            URLQueryItem(name: "api_key", value: "333ff82edf058458ae5ed32532e7f284")
        ]
    }
    
    var queryParameters: [URLQueryItem]? {
        switch self {
        case .movieGenres, .showGenres:
            return commonParameters
        case .discoverMovies(let genreID, let page):
            var params = commonParameters
            params.append(URLQueryItem(name: "with_genres", value: "\(genreID)"))
            params.append(URLQueryItem(name: "page", value: "\(page)"))
            return params
        case .discoverTV(let genreID, let page):
            var params = commonParameters
            params.append(URLQueryItem(name: "with_genres", value: "\(genreID)"))
            params.append(URLQueryItem(name: "page", value: "\(page)"))
            return params
        case .movieDetails(let movieID):
            var params = commonParameters
            params.append(URLQueryItem(name: "movie_id", value: "\(movieID)"))
            return params
        case .showDetails(let showID):
            var params = commonParameters
            params.append(URLQueryItem(name: "series_id", value: "\(showID)"))
            return params
        }
    }
    
    var port: Int? {
        switch self {
        case .movieGenres, .showGenres, .discoverMovies, .discoverTV, .movieDetails, .showDetails:
            return nil
        }
    }
    
    var path: String {
        switch self {
        case .movieGenres:
            return "/genre/movie/list"
        case .showGenres:
            return "/genre/tv/list"
        case .discoverMovies:
            return "/discover/movie"
        case .discoverTV:
            return "/discover/tv"
        case .movieDetails(let movieID):
            return "/movie/\(movieID)"
        case .showDetails(let showID):
            return "/tv/\(showID)"
        }
    }
    
    var method: RequestMethod {
        switch self {
        case .movieGenres, .showGenres, .discoverMovies, .discoverTV, .movieDetails, .showDetails:
            return .get
        }
    }
    
    var header: [String : String]? {
        var headerDict: [String: String] = [:]
        headerDict["accept"] = "application/json"
        
        return headerDict
    }
    
    var body: Data? {
        switch self {
        case .movieGenres, .showGenres, .discoverMovies, .discoverTV, .movieDetails, .showDetails:
            return nil
        }
    }
    
    func encodeCodableObject<T: Codable>(_ object: T) -> Data? {
        let encoder = JSONEncoder()
        do {
            let data = try encoder.encode(object)
            return data
        } catch {
            print("Error encoding codable object: \(error)")
            return nil
        }
    }
}


