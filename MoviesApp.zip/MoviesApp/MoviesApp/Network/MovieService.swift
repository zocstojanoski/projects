//
//  MovieService.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/18/23.
//

import Foundation

protocol MovieServiceable {
    func getMovieGenres() async -> Result<MovieGenresResponse, RequestError>
    func getShowGenres() async -> Result<MovieGenresResponse, RequestError>
    func discoverMovies(genreID: Int, page: Int) async -> Result<MovieDiscoveryResponse, RequestError>
    func discoverTV(genreID: Int, page: Int) async -> Result<MovieDiscoveryResponse, RequestError>
    func getMovieDetails(movieID: Int) async -> Result<MovieShow, RequestError>
    func getShowDetails(showID: Int) async -> Result<MovieShow, RequestError>
}

struct MovieService: HTTPClient, MovieServiceable {
    func getMovieGenres() async -> Result<MovieGenresResponse, RequestError> {
        return await sendRequest(endpoint: MovieEndpoint.movieGenres, responseModel: MovieGenresResponse.self)
    }
    
    func getShowGenres() async -> Result<MovieGenresResponse, RequestError> {
        return await sendRequest(endpoint: MovieEndpoint.showGenres, responseModel: MovieGenresResponse.self)
    }
    
    func discoverMovies(genreID: Int, page: Int) async -> Result<MovieDiscoveryResponse, RequestError> {
        return await sendRequest(endpoint: MovieEndpoint.discoverMovies(genreID: genreID, page: page), responseModel: MovieDiscoveryResponse.self)
    }
    
    func discoverTV(genreID: Int, page: Int) async -> Result<MovieDiscoveryResponse, RequestError> {
        return await sendRequest(endpoint: MovieEndpoint.discoverTV(genreID: genreID, page: page), responseModel: MovieDiscoveryResponse.self)
    }
    
    func getMovieDetails(movieID: Int) async -> Result<MovieShow, RequestError> {
        return await sendRequest(endpoint: MovieEndpoint.movieDetails(movieID: movieID), responseModel: MovieShow.self)
    }
    
    func getShowDetails(showID: Int) async -> Result<MovieShow, RequestError> {
        return await sendRequest(endpoint: MovieEndpoint.showDetails(showID: showID), responseModel: MovieShow.self)
    }
}


