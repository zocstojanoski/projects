//
//  MovieService.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/18/23.
//

import RxSwift

protocol MovieServiceable {
    func getMovieGenres() -> Observable<MovieGenresResponse>
    func getShowGenres() -> Observable<MovieGenresResponse>
    func discoverMovies(genreID: Int, page: Int) -> Observable<MovieDiscoveryResponse>
    func discoverTV(genreID: Int, page: Int) -> Observable<MovieDiscoveryResponse>
    func getMovieDetails(movieID: Int) -> Observable<MovieShow>
    func getShowDetails(showID: Int) -> Observable<MovieShow>
}

struct MovieService: MovieServiceable {
    
    func getMovieGenres() -> Observable<MovieGenresResponse> {
        return sendRequest(endpoint: MovieEndpoint.movieGenres, responseModel: MovieGenresResponse.self)
    }
    
    func getShowGenres() -> Observable<MovieGenresResponse> {
        return sendRequest(endpoint: MovieEndpoint.showGenres, responseModel: MovieGenresResponse.self)
    }
    
    func discoverMovies(genreID: Int, page: Int) -> Observable<MovieDiscoveryResponse> {
        return sendRequest(endpoint: MovieEndpoint.discoverMovies(genreID: genreID, page: page), responseModel: MovieDiscoveryResponse.self)
    }
    
    func discoverTV(genreID: Int, page: Int) -> Observable<MovieDiscoveryResponse> {
        return sendRequest(endpoint: MovieEndpoint.discoverTV(genreID: genreID, page: page), responseModel: MovieDiscoveryResponse.self)
    }
    
    func getMovieDetails(movieID: Int) -> Observable<MovieShow> {
        return sendRequest(endpoint: MovieEndpoint.movieDetails(movieID: movieID), responseModel: MovieShow.self)
    }
    
    func getShowDetails(showID: Int) -> Observable<MovieShow> {
        return sendRequest(endpoint: MovieEndpoint.showDetails(showID: showID), responseModel: MovieShow.self)
    }
    
    private func sendRequest<T: Decodable>(endpoint: MovieEndpoint, responseModel: T.Type) -> Observable<T> {
        return Observable.create { observer in
            let urlRequest = createUrlRequest(for: endpoint)
            let task = URLSession.shared.rx.data(request: urlRequest!)
                .subscribe(onNext: { data in
                    do {
                        let decodedResponse = try JSONDecoder().decode(T.self, from: data)
                        observer.onNext(decodedResponse)
                        observer.onCompleted()
                    } catch {
                        observer.onError(RequestError.decode)
                    }
                }, onError: { error in
                    observer.onError(error)
                })
            
            return Disposables.create([task])
        }
    }
    
    private func createUrlRequest(for endpoint: Endpoint) -> URLRequest? {
        let base = "\(endpoint.scheme)://\(endpoint.host)"
        let fullPath = "\(base)\(endpoint.path)"
        
        let queryString = endpoint.queryParameters?
            .map { "\($0.name)=\($0.value ?? "")" }
            .joined(separator: "&")
            .replacingOccurrences(of: "+", with: "%2B")
            .replacingOccurrences(of: ":", with: "%3A")
        
        let urlString = "\(fullPath)?\(queryString ?? "")"
        
        guard let url = URL(string: urlString) else {
            return nil
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = endpoint.method.rawValue
        request.allHTTPHeaderFields = endpoint.header
        
        if let body = endpoint.body {
            request.httpBody = body
        }
        
        print("tuka \(urlString)")
        return request
    }
}
