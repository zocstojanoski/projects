//
//  RequestError.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/18/23.
//

import Foundation

enum RequestError: Error {
    case decode
    case invalidURL
    case noResponse
    case unauthorized
    case unexpectedStatusCode
    case unknown
    case clientError(message: String?)
    
    var customMessage: String {
        switch self {
        case .decode:
            return "Decode error"
        case .unauthorized:
            return "Session expired"
        case .clientError(let message) where message != nil:
            return message!
        default:
            return "Something Went Wrong"
        }
    }
}

