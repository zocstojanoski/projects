//
//   MovieConstants.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/19/23.
//

struct MovieConstants {
    static let imageBaseURL = "https://image.tmdb.org/t/p/w500/"
}

