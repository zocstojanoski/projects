//
//  MovieShowCellViewModel.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/19/23.
//

import RxSwift

class MovieShowCellViewModel {

    // Outputs
    let budget: BehaviorSubject<String> = BehaviorSubject(value: "")
    let revenue: BehaviorSubject<String> = BehaviorSubject(value: "")
    
    let lastAirDate: BehaviorSubject<String> = BehaviorSubject(value: "")
    let lastEpisodeToAir: BehaviorSubject<String> = BehaviorSubject(value: "")
    private let disposeBag = DisposeBag()

    // Initializer
    init(movie: MovieShow, fetchDetails: @escaping (Int, @escaping (MovieShow?) -> Void) -> Void) {

        if movie.revenue == nil, movie.budget == nil, let movieID = movie.id {
            fetchDetails(movieID) { [weak self] updatedMovie in
                if let budgetValue = updatedMovie?.budget {
                    self?.budget.onNext("Budget: \(budgetValue)")
                } else {
                    self?.budget.onNext("Budget: NA")
                }
                
                if let revenueValue = updatedMovie?.revenue {
                    self?.revenue.onNext("Revenue: \(revenueValue)")
                } else {
                    self?.revenue.onNext("Revenue: NA")
                }
                
                if let lastAirDate = updatedMovie?.lastAirDate {
                    self?.lastAirDate.onNext("Last Air Date: \(lastAirDate)")
                } else {
                    self?.lastAirDate.onNext("Last Air Date: NA")
                }
                
                if let lastEpisodeToAir = updatedMovie?.lastEpisodeToAir {
                    self?.lastEpisodeToAir.onNext("Last Episode: \(lastEpisodeToAir.name)")
                } else {
                    self?.lastEpisodeToAir.onNext("Last Episode: NA")
                }
            }
        }
    }
}
