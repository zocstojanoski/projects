//
//  MoviesViewModel.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/18/23.
//

import Foundation
import RxCocoa
import RxSwift

class MoviesViewModel {
    
    // MARK: - Properties
    
    private let service = MovieService()
    public var genres: BehaviorSubject<[Genre]> = BehaviorSubject(value: [])
    public var movies: BehaviorSubject<[MovieShow]> = BehaviorSubject(value: [])
    var moviesCollection: [Int: [MovieShow]] = [:]
    var pageCollection: [Int: Int] = [:]
    
    public var didChangeGenre: PublishSubject<Void> = PublishSubject()
    private let disposeBag = DisposeBag()
    
    
    // MARK: - Other Methods
    
    func fetchGenres() {
        service.getMovieGenres().share(replay: 1)
            .subscribe(onNext: { [weak self] movieGenresResponse in
                self?.genres.onNext(movieGenresResponse.genres)
                
                if let moviesValue = try? self?.movies.value(), moviesValue.isEmpty {
                    self?.cellSelected(at: 0)
                }
            }, onError: { error in
                print("Error: \(error)")
            }).disposed(by: disposeBag)
    }
    
    func cellSelected(at index: Int) {
        guard let selectedGenre = getSelectedGenre(at: index) else { return }
        
        if moviesCollection[selectedGenre.id]?.isEmpty ?? true {
            fetchMovies(for: selectedGenre.id, page: 1)
        } else {
            self.movies.onNext(moviesCollection[selectedGenre.id] ?? [])
        }
        
        didChangeGenre.onNext(())
    }
    
    func fetchNextPage(at index: Int) {
        guard let selectedGenre = getSelectedGenre(at: index) else { return }
        
        let nextPage = (pageCollection[selectedGenre.id] ?? 1) + 1
        
        if nextPage <= 500 {
            fetchMovies(for: selectedGenre.id, page: nextPage)
        }
    }
    
    func refreshMovies(at index: Int) {
        guard let selectedGenre = getSelectedGenre(at: index) else { return }
        
        pageCollection[selectedGenre.id] = 1
        moviesCollection[selectedGenre.id] = nil
        fetchMovies(for: selectedGenre.id, page: 1)
    }
    
    private func getSelectedGenre(at index: Int) -> Genre? {
        guard let genreList = try? genres.value(), genreList.count > index else { return nil }
        return genreList[index]
    }
    
    private func fetchMovies(for genreID: Int, page: Int) {
        service.discoverMovies(genreID: genreID, page: page).share(replay: 1)
            .subscribe(onNext: { [weak self] moviesList in
                self?.pageCollection[genreID] = page
                
                if var moviesCollectionByGenre = self?.moviesCollection[genreID] {
                    moviesCollectionByGenre.append(contentsOf: moviesList.results)
                    self?.moviesCollection[genreID] = moviesCollectionByGenre
                } else {
                    self?.moviesCollection[genreID] = moviesList.results
                }
                
                self?.movies.onNext(self?.moviesCollection[genreID] ?? [])
                
            }, onError: { error in
                print("Error: \(error)")
            }).disposed(by: disposeBag)
    }
    
    
    func fetchMovieDetails(for movieID: Int, index: Int, completion: @escaping (MovieShow?) -> Void) {
        service.getMovieDetails(movieID: movieID).share(replay: 1)
            .subscribe(onNext: { movie in
                self.updateMovieTitle(movieId: movieID, index: index, movie: movie)
                completion(movie)
            }, onError: { error in
                print("Error fetching movie details: \(error)")
                completion(nil)
            }).disposed(by: disposeBag)
    }
    
    private func updateMovieTitle(movieId: Int, index: Int, movie: MovieShow) {
        guard let selectedGenre = getSelectedGenre(at: index) else { return }
        
        if var movies = moviesCollection[selectedGenre.id] {
            if let index = movies.firstIndex(where: { $0.id == movieId }) {
                movies[index] = movie
                moviesCollection[selectedGenre.id] = movies
            }
        }
    }
}

