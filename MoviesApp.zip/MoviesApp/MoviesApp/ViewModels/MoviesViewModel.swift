//
//  MoviesViewModel.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/18/23.
//

import Foundation
import RxCocoa
import RxSwift

class MoviesViewModel {
    
    // MARK: - Properties
    
    private let service = MovieService()
    public var genres: BehaviorSubject<[Genre]> = BehaviorSubject(value: [])
    public var movies: BehaviorSubject<[MovieShow]> = BehaviorSubject(value: [])
    var moviesCollection: [Int: [MovieShow]] = [:]
    var pageCollection: [Int: Int] = [:]
    
    public var didChangeGenre: PublishSubject<Void> = PublishSubject()
    
    
    // MARK: - Other Methods
    
    func fetchGenres() {
        Task(priority: .background) {
            let result = await service.getMovieGenres()
            switch result {
            case .success(let list):
                genres.onNext(list.genres)
                
                if let moviesValue = try? movies.value(), moviesValue.isEmpty {
                    cellSelected(at: 0)
                }
            case .failure(let error):
                print(error)
            }
        }
        
    }
    
    func cellSelected(at index: Int) {
        guard let selectedGenre = getSelectedGenre(at: index) else { return }
        
        if moviesCollection[selectedGenre.id]?.isEmpty ?? true {
            fetchMovies(for: selectedGenre.id, page: 1)
        } else {
            self.movies.onNext(moviesCollection[selectedGenre.id] ?? [])
        }
        
        didChangeGenre.onNext(())
    }
    
    func fetchNextPage(at index: Int) {
        guard let selectedGenre = getSelectedGenre(at: index) else { return }
        
        let nextPage = (pageCollection[selectedGenre.id] ?? 1) + 1
        
        if nextPage <= 500 {
            fetchMovies(for: selectedGenre.id, page: nextPage)
        }
    }
    
    func refreshMovies(at index: Int) {
        guard let selectedGenre = getSelectedGenre(at: index) else { return }
        
        pageCollection[selectedGenre.id] = 1
        moviesCollection[selectedGenre.id] = nil
        fetchMovies(for: selectedGenre.id, page: 1)
    }
    
    private func getSelectedGenre(at index: Int) -> Genre? {
        guard let genreList = try? genres.value(), genreList.count > index else { return nil }
        return genreList[index]
    }
    
    private func fetchMovies(for genreID: Int, page: Int) {
        Task {
            let result = await service.discoverMovies(genreID: genreID, page: page)
            
            switch result {
            case .success(let moviesList):
                pageCollection[genreID] = page
                
                if var moviesCollectionByGenre = moviesCollection[genreID] {
                    moviesCollectionByGenre.append(contentsOf: moviesList.results)
                    moviesCollection[genreID] = moviesCollectionByGenre
                } else {
                    moviesCollection[genreID] = moviesList.results
                }
                
                self.movies.onNext(moviesCollection[genreID] ?? [])
                
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func fetchMovieDetails(for movieID: Int, completion: @escaping (MovieShow?) -> Void) {
        Task {
            let result = await service.getMovieDetails(movieID: movieID)
            switch result {
            case .success(let movie):
                completion(movie)
            case .failure(let error):
                print("Error fetching movie details: \(error)")
                completion(nil)
            }
        }
    }
}

