//
//  ShowsViewModel.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/19/23.
//

import Foundation
import RxCocoa
import RxSwift

class ShowsViewModel {
    
    // MARK: - Properties
    
    private let service = MovieService()
    public var genres: BehaviorSubject<[Genre]> = BehaviorSubject(value: [])
    public var shows: BehaviorSubject<[MovieShow]> = BehaviorSubject(value: [])
    var showsCollection: [Int: [MovieShow]] = [:]
    var pageCollection: [Int: Int] = [:]
    
    public var didChangeGenre: PublishSubject<Void> = PublishSubject()
    private let disposeBag = DisposeBag()
    
    // MARK: - Other Methods
    
    func fetchGenres() {
        service.getShowGenres()
            .observe(on: MainScheduler.instance)
            .subscribe(onNext: { list in
                self.genres.onNext(list.genres)
                
                if let showsValue = try? self.shows.value(), showsValue.isEmpty {
                    self.cellSelected(at: 0)
                }
            }, onError: { error in
                print(error)
            }).disposed(by: disposeBag)
    }
    
    
    func cellSelected(at index: Int) {
        guard let selectedGenre = getSelectedGenre(at: index) else { return }
        
        if showsCollection[selectedGenre.id]?.isEmpty ?? true {
            fetchShows(for: selectedGenre.id, page: 1)
        } else {
            self.shows.onNext(showsCollection[selectedGenre.id] ?? [])
        }
        
        didChangeGenre.onNext(())
    }
    
    func fetchNextPage(at index: Int) {
        guard let selectedGenre = getSelectedGenre(at: index) else { return }
        
        let nextPage = (pageCollection[selectedGenre.id] ?? 1) + 1
        
        if nextPage <= 500 {
            fetchShows(for: selectedGenre.id, page: nextPage)
        }
    }
    
    func refreshShows(at index: Int) {
        guard let selectedGenre = getSelectedGenre(at: index) else { return }
        
        pageCollection[selectedGenre.id] = 1
        showsCollection[selectedGenre.id] = nil
        fetchShows(for: selectedGenre.id, page: 1)
    }
    
    private func getSelectedGenre(at index: Int) -> Genre? {
        guard let genreList = try? genres.value(), genreList.count > index else { return nil }
        return genreList[index]
    }
    
    private func fetchShows(for genreID: Int, page: Int) {
        service.discoverTV(genreID: genreID, page: page)
            .observe(on: MainScheduler.instance)
            .subscribe(onNext: { showsList in
                self.pageCollection[genreID] = page
                
                if var showsCollectionByGenre = self.showsCollection[genreID] {
                    showsCollectionByGenre.append(contentsOf: showsList.results)
                    self.showsCollection[genreID] = showsCollectionByGenre
                } else {
                    self.showsCollection[genreID] = showsList.results
                }
                
                self.shows.onNext(self.showsCollection[genreID] ?? [])
                
            }, onError: { error in
                print(error)
            }).disposed(by: disposeBag)
    }
    
    
    func fetchShowDetails(for showID: Int, completion: @escaping (MovieShow?) -> Void) {
        service.getShowDetails(showID: showID)
            .observe(on: MainScheduler.instance)
            .subscribe(onNext: { show in
                completion(show)
            }, onError: { error in
                print("Error fetching show details: \(error)")
                completion(nil)
            }).disposed(by: disposeBag)
    }
}
