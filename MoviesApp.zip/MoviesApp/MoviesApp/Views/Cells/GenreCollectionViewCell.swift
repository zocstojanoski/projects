//
//  GenreCollectionViewCell.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/18/23.
//

import UIKit

public final class GenreCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var baseView: UIView!
    
    var isCellSelected: Bool = false {
        didSet {
            updateSelectionState()
        }
    }
    
    override public func awakeFromNib() {
        super.awakeFromNib()
    }
    
    public override func prepareForReuse() {
        super.prepareForReuse()
        isCellSelected = false
    }
    
    private func updateSelectionState() {
        baseView.alpha = isCellSelected ? 0.2 : 0.1
    }
    
    func configure(genre: String) {
        label.text = genre
        applyRoundedCorners()
    }
    
    private func applyRoundedCorners() {
        self.layer.cornerRadius = 30
        self.clipsToBounds = true
    }
}

