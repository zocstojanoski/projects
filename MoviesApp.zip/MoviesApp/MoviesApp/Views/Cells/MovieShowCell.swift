//
//  MovieShowCell.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/19/23.
//

import UIKit
import RxSwift

public final class MovieShowCell: UICollectionViewCell {
    
    // MARK: - Outlets
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var thirdLabel: UILabel!
    @IBOutlet weak var forthLabel: UILabel!
    
    
    // MARK: - Properties
    
    private var viewModel: MovieShowCellViewModel?
    private var disposeBag = DisposeBag()
    
    // MARK: - Initialization
    
    override public func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = UIColor(white: 0.8, alpha: 0.15)
    }
    
    // MARK: - Configuration
    
    func configureMovie(movie: MovieShow, index: Int, fetchDetails: @escaping (Int, Int, @escaping (MovieShow?) -> Void) -> Void) {
        setupCommonUI(for: movie)
        
        viewModel = MovieShowCellViewModel(movie: movie, index: index, fetchDetails: fetchDetails)
        
        viewModel?.budget
            .bind(to: thirdLabel.rx.text)
            .disposed(by: disposeBag)
        
        viewModel?.revenue
            .bind(to: forthLabel.rx.text)
            .disposed(by: disposeBag)
    }
    
    func configureMovie(movie: MovieShow) {
        setupCommonUI(for: movie)
        if let budget = movie.budget, let revenue = movie.revenue {
            thirdLabel.text = "Budget: \(budget)"
            forthLabel.text = "Revenue: \(revenue)"
        }
    }
    
    func configureShow(show: MovieShow, index: Int, fetchDetails: @escaping (Int, Int, @escaping (MovieShow?) -> Void) -> Void) {
        setupCommonUI(for: show, isShow: true)
        
        viewModel = MovieShowCellViewModel(movie: show, index: index, fetchDetails: fetchDetails)
        
        viewModel?.lastAirDate
            .bind(to: thirdLabel.rx.text)
            .disposed(by: disposeBag)
        
        viewModel?.lastEpisodeToAir
            .bind(to: forthLabel.rx.text)
            .disposed(by: disposeBag)
    }
    
    func configureShow(show: MovieShow) {
        setupCommonUI(for: show)
        if let lastAirDate = show.lastAirDate, let lastEpisodeToAir = show.lastEpisodeToAir?.name {
            thirdLabel.text = "Last Air Date: \(lastAirDate)"
            forthLabel.text = "Last Episode: \(lastEpisodeToAir)"
        }
    }
    
    // MARK: - Cell Reuse
    
    public override func prepareForReuse() {
        super.prepareForReuse()
        imageView?.image = nil
        disposeBag = DisposeBag()
    }
    
    // MARK: - Private Helpers
    
    private func setupCommonUI(for movie: MovieShow, isShow: Bool = false) {
        titleLabel.text = (isShow ? "Name: " : "Title: ") + (movie.name ?? movie.title ?? "")
        ratingLabel.text = "Rating: " + String(movie.voteAverage ?? 0.0)
        
        if let path = movie.backdropPath, let url = URL(string: "\(MovieConstants.imageBaseURL)\(path)") {
            imageView.setImage(fromURL: url)
        } else {
            if let placeholderImage = UIImage(systemName: "film") {
                imageView.image = placeholderImage
                imageView.contentMode = .scaleAspectFit
            }
        }
    }
}
