//
//  MovieShowCell.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/19/23.
//

import UIKit
import RxSwift

public final class MovieShowCell: UICollectionViewCell {
    
    // MARK: - Outlets
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var thirdLabel: UILabel!
    @IBOutlet weak var forthLabel: UILabel!
    
    
    // MARK: - Properties
    
    private var viewModel: MovieShowCellViewModel?
    private var disposeBag = DisposeBag()
    
    // MARK: - Initialization
    
    override public func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = UIColor(white: 0.8, alpha: 0.15)
    }
    
    // MARK: - Configuration
    
    func configureMovie(movie: MovieShow, fetchDetails: @escaping (Int, @escaping (MovieShow?) -> Void) -> Void) {
        setupCommonUI(for: movie)
        
        viewModel = MovieShowCellViewModel(movie: movie, fetchDetails: fetchDetails)
        
        viewModel?.budget
            .bind(to: thirdLabel.rx.text)
            .disposed(by: disposeBag)
        
        viewModel?.revenue
            .bind(to: forthLabel.rx.text)
            .disposed(by: disposeBag)
    }
    
    func configureShow(movie: MovieShow, fetchDetails: @escaping (Int, @escaping (MovieShow?) -> Void) -> Void) {
        setupCommonUI(for: movie, isShow: true)
        
        viewModel = MovieShowCellViewModel(movie: movie, fetchDetails: fetchDetails)
        
        viewModel?.lastAirDate
            .bind(to: thirdLabel.rx.text)
            .disposed(by: disposeBag)
        
        viewModel?.lastEpisodeToAir
            .bind(to: forthLabel.rx.text)
            .disposed(by: disposeBag)
    }
    
    // MARK: - Cell Reuse
    
    public override func prepareForReuse() {
        super.prepareForReuse()
        imageView?.image = nil
        disposeBag = DisposeBag()
    }
    
    // MARK: - Private Helpers
    
    private func setupCommonUI(for movie: MovieShow, isShow: Bool = false) {
        titleLabel.text = (isShow ? "Name: " : "Title: ") + (movie.name ?? movie.title ?? "")
        ratingLabel.text = "Rating: " + String(movie.voteAverage ?? 0.0)
        
        if let path = movie.backdropPath, let url = URL(string: "\(MovieConstants.imageBaseURL)\(path)") {
            imageView.setImage(fromURL: url)
        } else {
            if let placeholderImage = UIImage(systemName: "film") {
                imageView.image = placeholderImage
                imageView.contentMode = .scaleAspectFit
            }
        }
    }
}
