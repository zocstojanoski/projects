//
//  MoviesViewController.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/18/23.
//

import UIKit
import RxCocoa
import RxSwift

class MoviesViewController: UIViewController {
    
    // MARK: - Outlets
    
    @IBOutlet weak var genreCollectionView: UICollectionView!
    @IBOutlet weak var movieCollectionView: UICollectionView!
    
    
    // MARK: - Properties
    
    let viewModel: MoviesViewModel = MoviesViewModel()
    let disposeBag = DisposeBag()
    let movieRefreshControl = UIRefreshControl()
    
    private var lastSelectedIndexPath: IndexPath? {
        didSet {
            if let oldValue = oldValue, let oldCell = genreCollectionView.cellForItem(at: oldValue) as? GenreCollectionViewCell {
                oldCell.isCellSelected = false
            }
            
            if let newValue = lastSelectedIndexPath, let newCell = genreCollectionView.cellForItem(at: newValue) as? GenreCollectionViewCell {
                newCell.isCellSelected = true
            }
        }
    }
    
    private let genreCellReuseIdentifier = "GenreCollectionViewCell"
    private let movieCellReuseIdentifier = "MovieShowCell"
    
    
    // MARK: - Lifecycle Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupCollectionViews()
        bindGenresToCollectionView()
        setupInfiniteScrolling()
        bindMoviesToCollectionView()
        viewModel.fetchGenres()
        observeGenreChanges()
    }
    
    // MARK: - Setup Methods
    
    private func setupCollectionViews() {
        setupGenresCollectionView()
        setupMoviesCollectionView()
    }
    
    private func setupGenresCollectionView() {
        genreCollectionView.register(UINib(nibName: "GenreCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: genreCellReuseIdentifier)
        genreCollectionView.delegate = self
    }
    
    private func setupMoviesCollectionView() {
        movieCollectionView.register(UINib(nibName: "MovieShowCell", bundle: nil), forCellWithReuseIdentifier: movieCellReuseIdentifier)
        movieCollectionView.delegate = self
        
        movieRefreshControl.addTarget(self, action: #selector(handleMovieRefresh), for: .valueChanged)
        movieCollectionView.refreshControl = movieRefreshControl
    }
    
    // MARK: - Binding Methods
    
    private func bindGenresToCollectionView() {
        bindGenresData()
        bindGenreSelection()
        ensureFirstGenreSelected()
    }
    
    private func bindMoviesToCollectionView() {
        viewModel.movies
            .bind(to: movieCollectionView.rx.items(cellIdentifier: movieCellReuseIdentifier, cellType: MovieShowCell.self)) { (row, movie, cell) in
                cell.configureMovie(movie: movie, fetchDetails: self.viewModel.fetchMovieDetails)
            }
            .disposed(by: disposeBag)
    }
    
    private func bindGenresData() {
        viewModel.genres
            .bind(to: genreCollectionView.rx.items(cellIdentifier: genreCellReuseIdentifier, cellType: GenreCollectionViewCell.self)) { [weak self] (row, element, cell) in
                cell.configure(genre: element.name)
                cell.isCellSelected = self?.lastSelectedIndexPath?.row == row
            }
            .disposed(by: disposeBag)
    }
    
    private func bindGenreSelection() {
        genreCollectionView.rx.itemSelected
            .subscribe(onNext: { [weak self] indexPath in
                self?.selectGenre(at: indexPath)
            })
            .disposed(by: disposeBag)
    }
    
    private func ensureFirstGenreSelected() {
        if lastSelectedIndexPath == nil {
            lastSelectedIndexPath = IndexPath(row: 0, section: 0)
        }
    }
    
    private func observeGenreChanges() {
        viewModel.didChangeGenre
            .observe(on: MainScheduler.instance)
            .subscribe(onNext: { [weak self] _ in
                self?.movieCollectionView.setContentOffset(.zero, animated: true)
            })
            .disposed(by: disposeBag)
    }
    
    private func selectGenre(at indexPath: IndexPath) {
        if lastSelectedIndexPath == indexPath {
            return
        }
        
        lastSelectedIndexPath = indexPath
        viewModel.cellSelected(at: indexPath.row)
    }
    
    private func setupInfiniteScrolling() {
        movieCollectionView.rx.willDisplayCell
            .filter { [weak self] (_, indexPath) in
                guard let self = self, let moviesCount = try? self.viewModel.movies.value().count else { return false }
                return indexPath.row == moviesCount - 5 // 5 is a buffer count; adjust as needed.
            }
            .throttle(RxTimeInterval.milliseconds(500), scheduler: MainScheduler.instance) // To avoid multiple calls
            .subscribe(onNext: { [weak self] _ in
                self?.loadNextPage()
            })
            .disposed(by: disposeBag)
    }
    
    private func loadNextPage() {
        if let index = lastSelectedIndexPath?.row {
            viewModel.fetchNextPage(at: index)
        }
    }
    
    @objc private func handleMovieRefresh() {
        if let index = lastSelectedIndexPath?.row {
            viewModel.refreshMovies(at: index)
        }
        
        viewModel.movies
            .take(1) // Take only the next emission
            .observe(on: MainScheduler.instance)
            .subscribe(onNext: { [weak self] _ in
                self?.movieRefreshControl.endRefreshing()
            })
            .disposed(by: disposeBag)
    }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension MoviesViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if collectionView == genreCollectionView {
            return CGSize(width: 120, height: 60)
        }
        
        let noOfCellsInRow = 2
        let flowLayout = collectionViewLayout as! UICollectionViewFlowLayout
        let totalSpace = calculateTotalSpacing(with: flowLayout, numberOfCells: noOfCellsInRow)
        
        let width = Int((collectionView.bounds.width - totalSpace) / CGFloat(noOfCellsInRow))
        let height = calculateHeight(forWidth: width)
        
        return CGSize(width: width, height: height)
    }
    
    private func calculateTotalSpacing(with layout: UICollectionViewFlowLayout, numberOfCells: Int) -> CGFloat {
        return layout.sectionInset.left + layout.sectionInset.right + (layout.minimumInteritemSpacing * CGFloat(numberOfCells - 1))
    }
    
    private func calculateHeight(forWidth width: Int) -> Int {
        let aspectRatio = 1.78
        let additionalSpace = 130.0
        return Int(Double(width) / aspectRatio + additionalSpace)
    }
    
}
