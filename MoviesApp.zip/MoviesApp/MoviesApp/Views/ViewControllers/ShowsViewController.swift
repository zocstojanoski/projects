//
//  ShowsViewController.swift
//  MoviesApp
//
//  Created by Zoran Stojanoski on 9/18/23.
//

import UIKit
import RxCocoa
import RxSwift

class ShowsViewController: UIViewController {
    
    // MARK: - Properties

    @IBOutlet weak var genreCollectionView: UICollectionView!
    @IBOutlet weak var showsCollectionView: UICollectionView!
    
    
    // MARK: - Properties
    
    let viewModel: ShowsViewModel = ShowsViewModel()
    let disposeBag = DisposeBag()
    let showRefreshControl = UIRefreshControl()
    
    private var lastSelectedIndexPath: IndexPath? {
        didSet {
            if let oldValue = oldValue, let oldCell = genreCollectionView.cellForItem(at: oldValue) as? GenreCollectionViewCell {
                oldCell.isCellSelected = false
            }
            
            if let newValue = lastSelectedIndexPath, let newCell = genreCollectionView.cellForItem(at: newValue) as? GenreCollectionViewCell {
                newCell.isCellSelected = true
            }
        }
    }
    
    
    // MARK: - Lifecycle Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupCollectionViews()
        bindGenresToCollectionView()
        setupInfiniteScrolling()
        bindShowsToCollectionView()
        viewModel.fetchGenres()
        observeGenreChanges()
    }
    
    // MARK: - Setup Methods
    
    private func setupCollectionViews() {
        setupGenresCollectionView()
        setupShowsCollectionView()
    }
    
    private func setupGenresCollectionView() {
        genreCollectionView.register(UINib(nibName: MovieConstants.genreCellReuseIdentifier, bundle: nil), forCellWithReuseIdentifier: MovieConstants.genreCellReuseIdentifier)
        genreCollectionView.delegate = self
    }
    
    private func setupShowsCollectionView() {
        showsCollectionView.register(UINib(nibName: MovieConstants.movieShowCellReuseIdentifier, bundle: nil), forCellWithReuseIdentifier: MovieConstants.movieShowCellReuseIdentifier)
        showsCollectionView.delegate = self
        
        showRefreshControl.addTarget(self, action: #selector(handleMovieRefresh), for: .valueChanged)
        showsCollectionView.refreshControl = showRefreshControl
    }
    
    // MARK: - Binding Methods
    
    private func bindGenresToCollectionView() {
        bindGenresData()
        bindGenreSelection()
        ensureFirstGenreSelected()
    }
    
    private func bindShowsToCollectionView() {
        viewModel.shows
            .bind(to: showsCollectionView.rx.items(cellIdentifier: MovieConstants.movieShowCellReuseIdentifier, cellType: MovieShowCell.self)) { (row, show, cell) in
                
                if show.budget != nil && show.revenue != nil {
                    cell.configureShow(show: show)
                } else {
                    cell.configureShow(show: show, index: self.lastSelectedIndexPath?.row ?? 0, fetchDetails: self.viewModel.fetchMovieDetails)
                }
                
            }
            .disposed(by: disposeBag)
    }
    
    private func bindGenresData() {
        viewModel.genres
            .bind(to: genreCollectionView.rx.items(cellIdentifier: MovieConstants.genreCellReuseIdentifier, cellType: GenreCollectionViewCell.self)) { [weak self] (row, element, cell) in
                cell.configure(genre: element.name)
                cell.isCellSelected = self?.lastSelectedIndexPath?.row == row
            }
            .disposed(by: disposeBag)
    }
    
    private func bindGenreSelection() {
        genreCollectionView.rx.itemSelected
            .subscribe(onNext: { [weak self] indexPath in
                self?.selectGenre(at: indexPath)
            })
            .disposed(by: disposeBag)
    }
    
    private func ensureFirstGenreSelected() {
        if lastSelectedIndexPath == nil {
            lastSelectedIndexPath = IndexPath(row: 0, section: 0)
        }
    }
    
    private func observeGenreChanges() {
        viewModel.didChangeGenre
            .observe(on: MainScheduler.instance)
            .subscribe(onNext: { [weak self] _ in
                self?.showsCollectionView.setContentOffset(.zero, animated: true)
            })
            .disposed(by: disposeBag)
    }
    
    private func selectGenre(at indexPath: IndexPath) {
        if lastSelectedIndexPath == indexPath {
            return
        }
        
        lastSelectedIndexPath = indexPath
        viewModel.cellSelected(at: indexPath.row)
    }
    
    private func setupInfiniteScrolling() {
        showsCollectionView.rx.willDisplayCell
            .filter { [weak self] (_, indexPath) in
                guard let self = self, let showsCount = try? self.viewModel.shows.value().count else { return false }
                return indexPath.row == showsCount - 5
            }
            .throttle(RxTimeInterval.milliseconds(500), scheduler: MainScheduler.instance)
            .subscribe(onNext: { [weak self] _ in
                self?.loadNextPage()
            })
            .disposed(by: disposeBag)
    }
    
    private func loadNextPage() {
        if let index = lastSelectedIndexPath?.row {
            viewModel.fetchNextPage(at: index)
        }
    }
    
    @objc private func handleMovieRefresh() {
        if let index = lastSelectedIndexPath?.row {
            viewModel.refreshShows(at: index)
        }
        
        viewModel.shows
            .take(1) // Take only the next emission
            .observe(on: MainScheduler.instance)
            .subscribe(onNext: { [weak self] _ in
                self?.showRefreshControl.endRefreshing()
            })
            .disposed(by: disposeBag)
    }
}

// MARK: - UICollectionViewDataSource & UICollectionViewDelegateFlowLayout
extension ShowsViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if collectionView == genreCollectionView {
            return CGSize(width: 120, height: 60)
        }
        
        let noOfCellsInRow = 2
        let flowLayout = collectionViewLayout as! UICollectionViewFlowLayout
        let totalSpace = calculateTotalSpacing(with: flowLayout, numberOfCells: noOfCellsInRow)
        
        let width = Int((collectionView.bounds.width - totalSpace) / CGFloat(noOfCellsInRow))
        let height = calculateHeight(forWidth: width)
        
        return CGSize(width: width, height: height)
    }
    
    private func calculateTotalSpacing(with layout: UICollectionViewFlowLayout, numberOfCells: Int) -> CGFloat {
        return layout.sectionInset.left + layout.sectionInset.right + (layout.minimumInteritemSpacing * CGFloat(numberOfCells - 1))
    }
    
    private func calculateHeight(forWidth width: Int) -> Int {
        let aspectRatio = 1.78
        let additionalSpace = 130.0
        return Int(Double(width) / aspectRatio + additionalSpace)
    }
    
}
